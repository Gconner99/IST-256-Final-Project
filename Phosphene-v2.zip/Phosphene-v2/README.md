# Phosphene

A personal **visual instrument / digital darkroom** for experimental video art and digital photo art.

Not a Premiere or Photoshop clone. Phosphene is a GPU effect pipeline with a tactile, slightly weird control surface: drop in images or video, stack modular GLSL effects, randomize, feed the output back into itself, and export stills or frame-by-frame video.

## If you don’t write code

Do **not** open the files inside Cursor.

On Windows, open the folder in **File Explorer** and double-click **`Start Phosphene.bat`**. That opens a **private** Chrome or Edge window (not a tab in a Chrome you already had open). Unzip the whole folder: `PHOSPHENE.html` plus `phosphene.js`. If Chrome crashes, use **`Start Phosphene Safe.bat`** instead.

This branch is **Phosphene v2** (five collage kits). The older idol instrument is on the local-launcher branch.

Read `START HERE.txt` if you get stuck.

## Run (developers)

Open the folder that contains `package.json`.

### In Cursor (click Run)

1. Open the repo folder (not a parent folder).
2. Run **Phosphene** from the Run and Debug view (play button / `F5`).
3. The first time it runs `npm install`, then starts the app and opens http://127.0.0.1:5173.

Pick **Phosphene (desktop)** in the same dropdown if you want the Electron window.

You can also use Terminal → Run Task → `phosphene: serve`.

### From a terminal

```bash
npm install
npm run dev          # browser instrument at http://127.0.0.1:5173
npm run desktop      # optional Electron shell
npm test
```

Requires a browser (or Electron) with **WebGL2**.

## MVP

- Image + video import (drag/drop, replace, freeze a video frame as a still)
- **Soundtrack**: drop an MP3 / wav / ogg / m4a. Playback follows the song; the collage fly-through follows the mix. MP4 export keeps the part of the song currently playing (rewind first to start from the beginning).
- Procedural generators including a **heraldic collage** (tour / paper / giants / shower) so it makes pictures with no files
- Real-time WebGL2 preview (draft / preview / full quality)
- Layers: opacity, blend modes, transform, enable, duplicate
- Modular effects stack (bypass, reorder, per-effect mix + mask)
- Floaters kits: lumpy shapes, toy-pop icons (notes, piano, guitar, trumpet, drums, sax, boombox), votives, moths, charms
- Idol Grow (petals / halo / antenna / skirt / wings / horns / crystal / puff / quiet) and Coat (cream / moss / sodium / night / candy / jelly / grape / ice / lava)
- Procedural backgrounds: plasma, noise, bars, plus **Stars**, **Marsh**, **Oil**, **Paper**, **Cave**, **Stage** (toy-pop piano / notes / instruments), **Sketch** (sticker-notebook paper), **Felt**, **Foil**, **Plush**, **Yarn**, **Sequins**, **Quilt**, **Cork**, **Gingham**, **Sprinkle**, and **Velvet**
- ~20 effects including **Floaters**, **Idol**, **Luma key**, and **Dropout**
- Seeded randomization (all / selected / param) plus **Rand wacky** (outsider looks, short stacks)
- **Stamp chaos** rerolls overlay seeds and generator inks; **Print frame** captures the live picture as a still
- Global + per-layer **feedback bus** (amount, delay, opacity, scale, rotation, distortion)
- Basic masks (rect, circle, gradient, noise)
- Simple keyframe automation
- JSON project files (`.phos.json`) and source-independent presets
- Export: PNG, JPG, **MP4 clips up to 32s at 720p/1080p 30fps** (clips loop as-is; optional close-loop fade, song window from the live playhead), WebM, PNG image sequence (zip)
- Collage mash (two kits), named **color packs** (Brine / Candy / Ember / Neon…), live ground wash, night/neon wash, **Hypnotic / Classic** looks (flat two-ink poster vs the previous washed Field), **Poster / Club** desks (Poster hides fly-throughs), 3D fly-throughs (Rush / Tunnel / Gyre / Well / Hall / Drift / Braid / Sway) on Club, Drop / Spot music moves, stamp size / density / pace, a freeform 3D Chain move, **Field** (one stamp pattern looping seamlessly — Sunflower / Orbit plus Traffic / Cascade / Checker / Scan — plus **Snake**), a **Trance** slider that ties Tempo + Breathe + Pack, and Matter moves (Spring / Flow / Boids / Poles) with their own sliders
- Extra stamp packs: Kitchen, Sky, Street, Arcade, plus more icons in Circus / Fruit / Grove / Sweet
- Calmer randomizer (smaller, slower rolls) and **Cut edit** (downbeat-locked cuts on bars and half-bars)

## Architecture

```
src/
  core/        project state, timeline, presets, RNG, JSON
  engine/      WebGL2 renderer, FBOs, shader compiler
  effects/     one EffectType per look — add files, don't rewrite the app
  media/       image/video/audio loaders
  export/      still / sequence / webm / mp4 clips
  ui/          instrument chrome
electron/      desktop window
```

An effect is:

```ts
{
  id, name, category, params,
  extraUniforms,          // GLSL uniform decls
  applyGlsl: `vec4 apply(vec2 uv) { ... }`
}
```

The engine wraps `apply()` with mix + mask. Parameter `amount` becomes uniform `u_amount`. See `src/effects/HOW_TO_ADD.md`.

Rendering is a ping-pong FBO chain per layer, then blend-mode composite, then a global feedback ring buffer, then blit to the canvas. Export re-renders at the requested resolution (not a screen recording).

## Keys

| Key | Action |
| --- | --- |
| Space | Play / pause |
| R | Randomize selected |
| Shift+R | Randomize all |
| K | Keyframe the selected numeric param |
| Ctrl/Cmd+S | Save project JSON |
| ? | Help |

## Stack

Vite + TypeScript + WebGL2 (custom GLSL, no Three.js). Electron is an optional wrapper. This is the stack that makes dropping in a new fragment shader the smallest possible change.
